<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_da_courses';
$plugin->version = 2025050101;
$plugin->requires = 2020061500;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.0';