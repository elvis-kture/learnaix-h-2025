#!/usr/bin/env python3
"""
Simple hello world script for testing Snowflake stage execution
"""

print("Hello World!")
print("This Python script was executed from Snowflake stage via Flask API.")
print("Execution successful! ✅")
