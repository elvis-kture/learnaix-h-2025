<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_cortex';
$plugin->version = 2025050504; // Changed plugin URL from helloworld to cortex
$plugin->requires = 2020061500;